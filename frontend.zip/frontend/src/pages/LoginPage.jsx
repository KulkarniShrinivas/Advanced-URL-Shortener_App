import React from 'react';

const LoginPage = () => {
    const handleLogin = () => {
        window.location.href = 'http://localhost:5000/api/auth/google';
    };

    return (
        <div className="container">
            <h1>Welcome to the URL Shortener App</h1>
            <p>Please log in to create and manage your links.</p>
            <button onClick={handleLogin}>Login with Google</button>
        </div>
    );
};

export default LoginPage;

