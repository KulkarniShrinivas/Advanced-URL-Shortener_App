import React from 'react';

const LinkTable = ({ links, onViewAnalytics }) => { 
  if (!links || links.length === 0) {
    return <p>You haven't created any short URLs yet.</p>;
  }
  
  return (
    <>
      <h3>Your Shortened URLs</h3>
      <table className="links-table">
        <thead>
          <tr>
            <th>Short URL</th>
            <th>Long URL</th>
            <th>Topic</th>
            <th>Clicks</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {links.map((link) => (
            <tr key={link.alias}>
              <td>
                <a href={link.shortUrl} target="_blank" rel="noopener noreferrer">
                  {link.shortUrl.split('/').pop()}
                </a>
              </td>
              <td>{link.longUrl}</td>
              <td>{link.topic || 'N/A'}</td>
              <td>{link.totalClicks}</td>
              <td className="actions">
                <button 
                  className="analytics" 
                  onClick={() => onViewAnalytics(link.alias)} 
                >
                  View Analytics
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};

export default LinkTable;