import React, { useState, useEffect } from 'react';
import axios from 'axios';
import LoginPage from './pages/LoginPage';
import Dashboard from './pages/Dashboard';
import Header from './components/Header';

const App = () => {
    const [user, setUser] = useState(null);
    const [links, setLinks] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        checkAuthStatus();
    }, []);

    const checkAuthStatus = async () => {
        try {
            // Making a request to a protected endpoint
            const response = await axios.get('/api/analytics/overall');
            if (response.status === 200 && response.data.user) {
                // Set the user state with data from the response
                setUser(response.data.user); 
                setLinks(response.data.urls);
            } else {
                setUser(null); // Ensure user is null if not authenticated
            }
        } catch (error) {
            setUser(null); // Set user to null on error
            console.error('Authentication check failed:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleLogin = () => {
        window.location.href = 'http://localhost:5000/api/auth/google';
    };

    const handleLogout = async () => {
        try {
            await axios.get('/api/auth/logout');
            setUser(null);
            setLinks([]);
            window.location.href = '/';
        } catch (error) {
            console.error('Logout failed:', error);
        }
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    return (
        <>
            <Header user={user} onLogin={handleLogin} onLogout={handleLogout} />
            {user ? (
                <Dashboard links={links} setLinks={setLinks} user={user} />
            ) : (
                <LoginPage onLogin={handleLogin} />
            )}
        </>
    );
};

export default App;